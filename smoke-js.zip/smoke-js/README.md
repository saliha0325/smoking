# smoke.js

A Pen created on CodePen.

Original URL: [https://codepen.io/rishu/pen/VWjPRw](https://codepen.io/rishu/pen/VWjPRw).

